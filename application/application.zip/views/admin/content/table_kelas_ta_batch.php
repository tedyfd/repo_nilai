<?php
$query = "select conf_kelas_th.id, GROUP_CONCAT(kelas.kelas ORDER BY FIND_IN_SET(kelas.id_kelas, conf_kelas_th.kelas)) as kelas, conf_kelas_th.nama
from kelas	
join conf_kelas_th ON find_in_set(kelas.id_kelas, conf_kelas_th.kelas) > 0
group by conf_kelas_th.nama";
$kelas_ta = $this->db->query($query)->result_array();
$th = $this->db->get('th_ajaran')->result_array();
?>
<div class="row">
    <div class="col">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="mb-0"> Kelas Tahun Ajaran </h3>
                    </div>
                    <div class="col-4 text-right">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form method="POST" action="<?= base_url('admin/kelas_ta_batch') ?>" id="form">
                    <h6 class="heading-small text-muted mb-4">Kelas Berdasarkan Tahun Ajaran</h6>
                    <div class="pl-lg-4">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="kelas">Kelas</label>
                                    <select name="kelas" id="kelas" class="form-control">
                                        <option value=""></option>
                                        <?php foreach ($kelas_ta as $l) : ?>
                                        <option value="<?= $l['id'] ?>">(<?= $l['nama'] ?>)<?= $l['kelas'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('kelas', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-control-label" for="ta">Tahun Ajaran</label>
                                    <select name="ta" id="ta" class="form-control">
                                        <option value=""></option>
                                        <?php foreach ($th as $l) : ?>
                                        <option value="<?= $l['id_th'] ?>"><?= $l['th_ajaran'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('ta', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="col btn btn-lg btn-primary submit-btn">Submit</button>
                            </div>
                        </div>
                    </div>
                    <hr class="my-4" />
                </form>
            </div>
        </div>
    </div>
</div>